package com.newsapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.newsapp.domain.News;
import com.newsapp.repository.NewsRepository;


@Service
public class NewsServiceImpl implements NewsService {

	@Autowired
	private NewsRepository newsRepository;
	@Override
	public News addNews(News news) {
		// TODO Auto-generated method stub
		return newsRepository.save(news);
	}
	@Override
	public List<News> getAllNews() {
		
		return newsRepository.findAll();
	}
	@Override
	public List<News> getNews(String email) {
		List<News> news = newsRepository.findByEmail(email);
		
		return news;
		
	}

}
