package com.newsapp.service;

import java.util.List;

import com.newsapp.domain.News;

public interface NewsService {
public News addNews(News news);
public List<News> getAllNews();
public List<News> getNews(String email);
}
