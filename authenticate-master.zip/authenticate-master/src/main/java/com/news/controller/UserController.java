package com.news.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.news.domain.User;
import com.news.exception.UserAlreadyPresentException;
import com.news.exception.UserNotFoundException;
import com.news.repository.UserRepository;
import com.news.service.UserService;
import com.news.tokengenerator.TokenGenerator;
import com.news.tokengenerator.TokenGeneratorImpl;

@RestController
@CrossOrigin(origins="http://localhost:4200")


@RequestMapping("/api/v1/users")
public class UserController {

	private UserService userService;
	private UserRepository userRepository;
	
	@Autowired
	public UserController(UserService userService)
	{
		this.userService=userService;
	}
	
	@PostMapping("/addUser")
	public ResponseEntity<?> addUser(@RequestBody User user) throws UserAlreadyPresentException
	{
	        userService.addUser(user);
            return new ResponseEntity<User>(user,HttpStatus.OK);	        
	}
	
	@GetMapping("/getuser/{email}")
	public ResponseEntity<?> getUser(@PathVariable String email) throws UserNotFoundException{
		User user = userService.getUser(email);
		if(user!=null) {
			return new ResponseEntity<User>(user,HttpStatus.OK);
		}
		return new ResponseEntity<String>("User Not Found",HttpStatus.UNAUTHORIZED);
	}
	
	@PostMapping("/update/{email}")
	public ResponseEntity<?> updateUser(@PathVariable String email,@RequestBody String password) throws UserNotFoundException{
		User user = userRepository.findById(email).get();
		
			user.setPassword(password);
			User updated=userRepository.save(user);
			return new ResponseEntity<User>(updated,HttpStatus.OK);
		
	}
	
	
	
// http://localhost:8080/api/v1/users/validateUser/rajib@gmail.com
	
   @GetMapping("/validateUser/{email}")
   public ResponseEntity<?> validateUser(@PathVariable String email) throws UserNotFoundException 
  // we changed the parameter to fit according to the frontend from
   // where we are passing the email
   //public ResponseEntity<?> validateUser(@RequestBody User user)
   {
	   TokenGenerator tokenGenerator=null;
	   Map<String, String> tokenDetails=null;
	  // try
	   //{
	     User user =userService.getUser(email);
        if(user!=null)
        {
          tokenGenerator=new TokenGeneratorImpl();
          tokenDetails=tokenGenerator.generateToken(user);
	     
       }
	   //}catch(UserNotFoundException userNotFoundException)
	  // {
		   // error code is 404
        //return new ResponseEntity<String>("User unauthorised",HttpStatus.NOT_FOUND);
	  // }
	   
	   return new ResponseEntity<Map<String,String>>(tokenDetails,HttpStatus.OK);
   }
}