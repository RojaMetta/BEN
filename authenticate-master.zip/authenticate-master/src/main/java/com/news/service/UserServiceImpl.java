package com.news.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news.domain.User;
import com.news.exception.UserAlreadyPresentException;
import com.news.exception.UserNotFoundException;
import com.news.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	private UserRepository userRepository;
	
	@Autowired
	// autowiring by constructor
	public UserServiceImpl(UserRepository userRepository)
	{
		this.userRepository=userRepository;
	}
	
	@Override
	public User getUser(String email) throws UserNotFoundException {
	 
         //  User userFound=userRepository.findById(email).get();
          Optional<User> user=userRepository.findById(email);
		if(!user.isPresent())
           {
        	   throw new UserNotFoundException("User not found exception");
           }
	        User userFound=user.get();
	        return userFound;
	}

	// addUser
	@Override
	public User addUser(User user)   {
		// TODO Auto-generated method stub
		Optional<User> userAdd=userRepository.findById(user.getEmail());
		userRepository.save(user);
		return user;
	}

	@Override
	public List<User> allUsers() {
		// TODO Auto-generated method stub
		return null;
	}

}
