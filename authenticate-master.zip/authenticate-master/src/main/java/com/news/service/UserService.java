package com.news.service;

import java.util.List;

import com.news.domain.User;
import com.news.exception.UserAlreadyPresentException;
import com.news.exception.UserNotFoundException;

public interface UserService {
   public User getUser(String email) throws UserNotFoundException;
   public User addUser(User user) throws UserAlreadyPresentException;
   public List<User> allUsers();
}
