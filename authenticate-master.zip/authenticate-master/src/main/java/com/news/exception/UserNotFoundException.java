package com.news.exception;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
